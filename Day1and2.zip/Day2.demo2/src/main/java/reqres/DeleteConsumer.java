package reqres;

import java.util.Collections;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class DeleteConsumer {

	public static void main(String[] args) {
		String url = "https://reqres.in/api/users/2";
		RestTemplate template = new RestTemplate();
		template.setInterceptors(Collections.singletonList(new MyInterceptor()));
		
		ResponseEntity<String> str = template.exchange(url,HttpMethod.DELETE,null,String.class);
		System.out.println("Returned = " + str);
	}

}
