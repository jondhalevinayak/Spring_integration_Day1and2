package controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping(value="/second")
public class SecondController {
	
	@GetMapping(value="/m1")
	public String m1(){
		String str = "Get in m1 - SecondController";
		System.out.println(str);
		return str;
	}
	@GetMapping(value="/m2")
	public String m2(){
		String str = "Get in m2 - SecondController";
		System.out.println(str);
		return str;
	}
	
}
