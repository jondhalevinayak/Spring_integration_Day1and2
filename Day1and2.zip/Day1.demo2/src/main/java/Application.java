import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import demo.AsyncDemo;
import demo.Simple;

@SpringBootApplication(scanBasePackages="demo")
@EnableScheduling
@EnableAsync
public class Application {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
			ConfigurableApplicationContext ctx = SpringApplication.run(Application.class, args);
			Simple simple = ctx.getBean(Simple.class);
			for (int i = 0; i < 1; i++) {
				System.out.println(" i = "  +  i);
				simple.m1(i);
			}
			
			AsyncDemo demo = ctx.getBean(AsyncDemo.class);
			demo.method1();
			System.out.println("in main after method1....");
			
			Future<String> fstr = demo.method2();
			System.out.println("in main after method2....");
			
			demo.method1();
			System.out.println("in main after method1....");
			
			System.out.println("method2 return value = " + fstr.get());
				
			System.out.println("end of main....");
	}

	@Bean
	@Primary
	public TaskExecutor taskexe(){
		ThreadPoolTaskExecutor  txe = new ThreadPoolTaskExecutor();
	
		txe.setCorePoolSize(1);
		txe.setMaxPoolSize(10);
		txe.setQueueCapacity(5);
		return txe;
	}
	

	
}
