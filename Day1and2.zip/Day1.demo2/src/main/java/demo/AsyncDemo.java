package demo;

import java.util.concurrent.Future;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

@Component
public class AsyncDemo {
	@Async
	public void method1() {
		System.out.println(" start of  method1 of AsyncDemo .." + Thread.currentThread().getName());
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(" end of method1 of AsyncDemo");
	}
	@Async
	public Future<String> method2() {
		System.out.println(" start of  method2 of AsyncDemo .." + Thread.currentThread().getName());
		String s ="Starting...";
		try {
			Thread.sleep(500);
			s+=" sleep over ....";
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(" end of method2 of AsyncDemo");
		return new AsyncResult<String>(s+"complete");
	}
}
